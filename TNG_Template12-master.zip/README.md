# Only for TNG Template12 | This Stylesheet provides a lighter and better readable Version of Template12

1.
Copy mytngstyle.css in your TNG-root/templates/template12/css/ folder and overwrite the existing file. Normaly the mytngstyle.css in this folder contains no css code. Otherwise please make a backup.

2.
Copy all pictures in your TNG-root/templates/template12/img/ folder.
